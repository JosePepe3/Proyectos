from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer
from base_conocimientos import conocimientos
import logging

logging.basicConfig(filename='archivarlog.log', level=logging.DEBUG)

chatbot = ChatBot('Mitu')

chatbot.storage.drop()

entrenador = ListTrainer(chatbot)   #inicializa

entrenador.train(conocimientos) #realiza

def get_response(msg):
    """
    nombre = input("Reno: Hola, soy Reno :D! Tu asistente personal en telefonia de este año :D\n"
                "puedes preguntarme cualquier cosa de telefonos y recomendarte. Veamos....\n"
                "¿Por qué no me dices tu nombre?\t")

    print(f'¡Un gusto {nombre}!!! Puedes preguntarme lo que quieras sobre telefonos moviles, tambien puedo recomendarte con base en algun presupuesto :D.')
    """

    while True:

        if msg == 'adios':
            print('Mitu: ¡Hasta luego! :D')
            quit()
        respuesta = chatbot.get_response(msg)
        print('Mitu: ', respuesta)    

        return respuesta