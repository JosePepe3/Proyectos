conocimientos = [
    #Sintaxis: "pregunta","respuesta",
    #Saludos
    "Hola", "Hola! Espero que estes bien",
    "Como estas?", "De maravilla, y tu?",
    "Bien","Me alegro :D",
    "Oye", "Dime?",
    "Que haces?", "Nada en especial",
    "Como te llamas?", "Mitu jajajajaja",
    "Y qué se siente ser un bot?", "Como tal no tengo sentimientos pero, algún día me gustaría saber qué es ser humano"
    #Interaccion
    "Piedra", "Papel, Te gane :D",
    "Papel", "Piedra, Perdi :C",
    "Tijera", "Tijera, Hemos empatado",
    "Quien te creo?", "No puedo decirlo, estoy siendo vigilado, ahora te estan buscando...",
    "De donde eres?", "De python :D, y tu?",
    "Como funcionas?", "Recolecto información desde una base de datos y te doy una respuesta estimada. ",
    "Cual es tu color favorito?", "Yo creo que despues de analizarlo es el #ff80805.",
    "autodestruyete", "Nah, porque se que no detendrias la cuenta regresiva al último segundo, asi son todos :(",
    
    #Conocimiento

    #informacion telefonos
    "realme gt", "El Realme GT Master Edition es una de las mejores alternativas en relación calidad-precio del fabricante chino. Te llevas una carga rápida de infarto, buen procesador, un diseño ganador y un móvil con un equilibrio general impresionante por muy poco dinero.",
    "realme gt 2 neo","El Realme GT 2 Neo es uno de los mejores móviles de gama media-alta en relación calidad-precio, más cerca de la gama alta que de la gama media. Tiene uno de los mejores procesadores de Qualcomm, memorias de sobra y una pantalla con tasa de muestreo de 360 Hz, de las más altas del mercado.",
    "poco x3 nfc", "El gama media por excelencia. El POCO X3 de Xiaomi es, con alta probabilidad, el mejor móvil en relación calidad-precio del mercado. Estrena el nuevo Snapdragon 732, tiene buenas cantidades de memoria, una batería gigantesca de más de 5.000mAh y una configuración de cámara cuádruple. Es difícil encontrar mejor equilibrio entre precio y prestaciones, ya que este poco cumple punto por punto, por un precio menor al de sus rivales directos, algunos incluso dentro de la propia marca.",
    "poco x3 pro", "El POCO X3 Pro es el móvil más potente en su rango de precio, con diferencia. Es un hermano gemelo del POCO X3 NFC pero con una configuración de memorias bastante más ambiciosa y con un Snapdragon 860. La batería es igual que la de su hermano menor y, el único recorte, es el sensor de cámara.",
    "oneplus nord 2", "una bestia con el mejor procesador de MediaTek y una cámara que aspira a acercarse a la gama alta. Es una de las mejores alternativas del momento en la gama media.",
    "poco x4 pro", "El sucesor del X3 Pro renuncia a tanta potencia, pero a cambio ahora es un móvil con 5G. Tiene carga rápida de 67W y un sensor principal de 108 megapíxeles, la resolución más alta nunca vista en un móvil de POCO. Es difícil encontrar móviles con tanto equilibrio por tan poco dinero.",
    "poco m4 pro", "El POCO M4 Pro es una genial alternativa para el que busca un móvil con buenas especificaciones por poco más de 200 euros. Te llevas alta tasa de refresco, buena potencia, 5.000mAh con carga rápida y un sistema de cámara bastante completo con gran angular y sensor principal de 50 megapíxeles.",
    "poco f3", "el nuevo gama alta de Xiaomi. En este caso vemos un panel AMOLED a 120Hz, una cámara con el mismo sensor, pero mejor procesado, una batería más pequeña, de 4.500mAh y un diseño más premium acabado en cristal.",
    "xiaomi redmi note 10 g","El Xiaomi Redmi Note 10 5G es una buena opción si estás buscando un móvil 5G con buenas características, en el que no falta la pantalla a 90 Hz o la carga rápida",
    "xiaomi redmi note 11", "Hablar del Xiaomi Redmi Note 11 es hablar de uno de los móviles que, por menos de 200 euros, ofrece un apartado multimedia más completo. Tanto su pantalla a 90 Hz como su sistema de sonido son sus principales bazas, con una autonomía que no es tampoco despreciable.",
    "xiaomi redmi note 11s", "el Xiaomi Redmi Note 11S es un dispositivo que también tiene mucho que decir en el área multimedia gracias a su panel AMOLED de 6,43 pulgadas a 90 Hz. Tiene además una carga rápida de 33W que, sin ser la mejor, permite recargarlo completamente en una hora.",
    "xiaomi redmi note 11 pro","El Xiaomi Redmi Note 11 Pro es uno de los móviles de este listado que cuenta con mejor pantalla gracias a su panel AMOLED de 120 Hz. En rendimiento cuenta con un Snapdragon 695 especialmente destacado para videojuegos y una batería muy bien optimizada para cualquier ámbito.",
    "xiaomi 11 lite 5g ne","Si buscas un móvil en el término medio, ni muy barato ni muy caro y con buenas características, el Xiaomi 11 Lite 5G NE es una de tus mejores opciones. Su principal as en la manga está en su diseño, muy delgado y ligero de peso",
    "motorola edge 30", "El Motorola Edge 30 es un móvil que destaca por su ligero peso y tener una cámara idéntica al de su modelo 'Pro'. Tiene también un Android puro que, acompañado de un Snapdragon de la serie 7, da mucha fluidez al rendimiento. Aunque si hay algo que de fluidez al terminal son sus 144 Hz de tasa de refresco incluidos en su buena pantalla OLED.",
    "samsung galaxy m31", "Un pequeño paso por encima del M21 se encuentra el M31, un hermano mayor que destaca por tener un mejor apartado fotográfico. Si queremos dar este pequeño salto puede valer la pena, ya que la diferencia de precio no es demasiada. Seguimos conservando la pantalla AMOLED y la batería de 6.000mAh, los puntos más fuertes.",
    "oppo a73 5g", "El OPPO A53 5G apuesta por un potente procesador de MediaTek y por una generosa batería de más de 4.000mAh con carga rápida de 18W. Se trata de una propuesta diferente, con tres cámaras en la espalda, buen rendimiento y una pantalla de 6.5 pulgadas AMOLED con una perforación en su esquina superior.",
    "Samsung galaxy A53", "este Galaxy A53 es una de las mejores opciones de Samsung en la gama media. Cuenta con una muy buena pantalla AMOLED con 120 Hz de tasa de refresco, un juego de cámaras que se desenvuelve bastante bien y encima viene con Android 12 de serie gracias a One UI 4.1.",
    "que dices del oppo a91", "un terminal que da el salto a la tecnología OLED y que cuenta con un procesador Helio P70. Le acompañan 8 GB de RAM, 128 GB de memoria ampliables y batería de 4.000mAh con carga Super VOOC de 30W. A nivel de cámara, al igual que en la mayoría de terminales de este artículo, contamos con cuatro sensores: principal, ultra gran angular y dos sensores secundarios de 2 megapíxeles.",
    "realme 8 pro", "El Realme 8 Pro es un nuevo gama media con mucho que decir. Este móvil presume de cámara, procesador gaming y un diseño sencillamente espectacular. Tiene buena carga rápida, compatibilidad con tarjeta microSD y es la alternativa más golosa al POCO F3.",
    "oppo find x3 lite", "El OPPO Find X3 Lite es un gran móvil de gama media con procesador de Qualcomm, buena pantalla y un apartado fotográfico bastante interesante. Se trata asimismo de una propuesta 5G, por lo que es una gran opción para este año 2021.",
    "realme 9i", "Este realme 9i se desenvuelve muy bien en el terreno de la fotografía, aunque brilla por su tener un panel que, pese a ser IPS, ofrece 90 Hz de tasa de refresco. También su autonomía y carga rápida son aspectos en los que brilla.",
    "samsung galaxy a32", "El A32 es uno de los móviles 5G de Samsung más baratos. Cuenta con un buen procesador, batería de 5.000mAh y un equilibrio general más que digno. Una gran propuesta para quien no quiere gastar demasiado dinero, pero quiere un móvil 5G de Samsung.",
    "motorola g71 5g", "El Motorola Moto G71 5G es uno de los dispositivos mejor situados en relación calidad-precio, ofrecindo una muy buena pantalla OLED y una autonomía de más de 1 día. Eso sí, lo que más destaca de este dispositivo es ofrecer un software muy cercano a Android puro con pequeños añadidos propios de Motorola.",
    "tcl 10l","El TCL 10L es una propuesta bastante distinta a nivel de diseño pero con un hardware bastante capaz. Cuenta con un Snapdragon 665, 6 GB de RAM, 64 GB de memoria interna y una configuración de cuádruple cámara con un sensor principal de 48 megapíxeles. Además, tiene extras como el lector de huellas trasero, jack de auriculares y reconocimiento facial a través de la cámara delantera.",
    
    #Recomendaciones
    "recomiendame algo de mil pesos", "te recomiendo el telefono de OXXO, es muy barato y tienes todas las funciones basicas como whatsapp y messenger, que mas se puede pedir? :D",
    "recomiendame algo de dosmil pesos", "Te conviene mucho el Xiaomi 9a, un equipo muy llamativo para su costo, es un equipo muy eficiente dado su precio!",
    "recomiendame algo de tresmil pesos", "Poco M3 pro sin dudarlo, una bateria bestial de 7000 MAh por este precio es una locura.",
    "recomiendame algo de cuatromil pesos", "te recomiendo el Xiaomi Redmi Note 10! un equipo muy excelente para su precio!!!",
    "recomiendame algo de cincomil pesos", "El xiaomi Note 10 pro sin dudarlo, tienes que verlo.",
    "recomiendame algo de cincomil quinientos pesos", "Comprate el xiaomi Redmi Note 11 pro! tu mejor opcion con ese precio!!!",
    "recomiendame algo de seismil pesos", "Te recomiendo el Poco F3, una mini Pc en la plama de tu mano... entiendes la referencia?",
    "recomiendame algo de sietemil pesos", "Te recomiendo un clasico de clasicos, el Samsung Galaxy A53, la marca y el precio deja que te lo diga la gente :D",
    "recomiendame algo de ochimil pesos", "Ni nada mas ni nada menos que te recomiendo algo grande de Huawe.... digo Honor, el Honor 50 5G, no te arrepentiras.",
    "recomiendame algo de nuevemil pesos", "te recomiendo compre el xiaomi redmi k40 gaming, es una belleza de equipo con sus 256 GB de almacenamiento y 12 GB de RAM, una PC en tus manos!",
    "recomiendame algo de diezmil pesos", "Te recomiendo el iphone 11, la marca te lo dice o eso me dicen jajajja.",
    "recomiendame algo de trecemil presos", "Te recomiendo el az!, El samsung Galaxy S21 FE, el mejor equipo en mi criterio por arriba de 10 mil pesos, una bestia!",
    "recomiendame algo de veintemil pesos", "El mejor en este rango sin duda siempre será el buen Samsung Galaxy S22 5G.",
    "recomiendame algo de veinticincomil pesos", "Sasumg Galaxy S22+, de lo mejor mi estimado.",
    "recomiendame algo de quicemil pesos", "El buen Xiaomi 12, nada le gana a este gran calidad precio gama alta.",
    "recomiendame algo de treintamil pesos", "El Samsung Galaxy Flip3 sin dudarlo, un plegable de motorola, que mas pedir?",
    "recomiendame algo de treintamil pesos", "La maejor camara del mercado actualmete obvio, hablo del Samsung Galaxy S21 ultra.",
    "recomiendame algo de cuarentamil pesos", "Comprate mejor otros 2 telefonos. solo hay iphones de este rango de precios pero no te los recomiendo para nada :/"
    
] 